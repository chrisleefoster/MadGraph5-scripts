launch ttbarwpm-QCD 
order=NLO
fixed_order=ON
set ebeam1 3500
set ebeam2 3500
set req_acc_fo 0.001

exit

