set complex_mass_scheme True
set auto_convert_model T
import model loop_qcd_qed_sm-with_b_mass_no_widths
define wpm = w+ w-
generate p p > t t~ wpm [QCD QED]
output ttbarwpm-QCDQED
launch
order=NLO
fixed_order=ON
set MT 1.725000e+02
set MB 4.200000e+00
set aEWM1 1.278000e+02
set pdlabel lhapdf
set lhaid 27400
set fixed_ren_scale True
set fixed_fac_scale True
set mur_ref_fixed 172.5
set muf_ref_fixed 172.5
set ebeam1 6500
set ebeam2 6500
set reweight_pdf False
set reweight_scale False
set req_acc_fo 0.001
exit
