import model loop_sm-zeromass_ckm
define wpm = w+ w-
generate p p > t t~ wpm [QCD]
output ttbarwpm-QCD
launch
order=NLO
fixed_order=ON
set MT 1.725000e+02
set pdlabel lhapdf
set lhaid 27400
set fixed_ren_scale True
set fixed_fac_scale True
set mur_ref_fixed 172.5
set muf_ref_fixed 172.5
set ebeam1 6800
set ebeam2 6800
set reweight_pdf True
set req_acc_fo 0.001
exit
